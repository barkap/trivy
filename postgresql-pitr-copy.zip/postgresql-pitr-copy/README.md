# PostgreSQL PITR PoC

Point-In-Time Recovery proof of concept using Percona for PostgreSQL 18 with Docker Compose.

Uses built-in PostgreSQL WAL archiving (`archive_command` / `restore_command`) and `pg_basebackup`. No extra backup tools required.

## Prerequisites

- Docker + Docker Compose v2

## Project layout

```
config/
  postgresql.conf   # WAL archiving settings (mounted into container)
  pg_hba.conf       # Authentication rules (mounted into container)
scripts/
  basebackup.sh     # Take a base backup
  restore.sh        # Restore to a specific point in time
docker-compose.yml
```

## Quick start

```bash
# 1. Fix permissions on data and backup directories (postgres runs as uid 999 inside the container)
sudo chown -R 999:999 ./data ./backup

# 2. Start the database
docker compose up -d

# 3. Verify it is running
docker compose logs postgres
```

## PITR walkthrough

### Step 1 — Take a base backup

```bash
# Creates a backup inside the pgdata volume at /var/lib/postgresql/basebackup
./scripts/basebackup.sh
```

Record the printed baseline timestamp (T0).

### Step 2 — Insert test data

```bash
# Connect to postgres
docker compose exec postgres psql

# Create a table and insert some rows
CREATE TABLE employees (id serial PRIMARY KEY, name text);
INSERT INTO employees (name) VALUES ('Alice'), ('Bob');
SELECT * FROM employees;
```

Record the current Riga time — this is your **recovery target (T1)**:

```bash
date '+%Y-%m-%d %H:%M:%S'
# e.g. 2026-04-13 15:00:00
```

### Step 3 — Simulate an accident

```bash
# Still in psql — delete all data
DELETE FROM employees;
SELECT * FROM employees;   -- returns 0 rows
\q
```

### Step 4 — Restore to T1

```bash
# Restore the database to the moment before the accident
./scripts/restore.sh "2026-04-13 12:00:00"
```

### Step 5 — Verify recovery

```bash
# Monitor recovery progress
docker compose logs -f postgres

# Once "database system is ready to accept connections" appears, connect
psql -h localhost -U postgres -c "SELECT * FROM employees;"
# Expected: Alice and Bob are back
```

## Backup maintenance

Base backups are stored as dated directories: `./backup/base/YYYY-MM-DD/`. Running `basebackup.sh` again on the same day replaces that day's backup.

**Recommended daily routine** (e.g. cron at 00:00):

```bash
# 1. Take a fresh base backup
./scripts/basebackup.sh

# 2. Remove base backups AND WAL older than 7 days
./scripts/cleanup.sh 7
```

Always run cleanup **after** the new base backup, never before. With a 7-day retention window, restoring to any point in the last 7 days will at most replay 1 day of WAL (since there is a base backup every 24 hours).

Available base backups are listed by:

```bash
ls ./backup/base/
```

## Stop / clean up

```bash
# Stop containers
docker compose down

# Remove containers AND data volumes (full reset)
docker compose down -v
```

## Notes

- `./data` — PostgreSQL data files. `./backup/wal` — WAL archive. `./backup/base` — base backup. All are bind-mounted into the container.
- **Timezone**: the server runs in `Europe/Riga`. All timestamps — logs, WAL, `recovery_target_time` — are in Riga local time. Always use `TZ='Europe/Riga' date` when recording timestamps for PITR. DST transitions (UTC+2 in winter, UTC+3 in summer) apply.
- Image: `perconalab/percona-distribution-postgresql:18.3` (public, no login required). If the pull fails on your architecture, try the explicit tag `18.3-amd64`.
- TDE (Transparent Data Encryption): config stubs are already in `postgresql.conf`. See the commented `pg_tde` section.


-----

# Scripts

```
./scripts/reset_all.sh
./scripts/init.sh
docker compose up -d
sleep 3
docker compose exec postgres psql -c "CREATE TABLE employees (id serial PRIMARY KEY, name text); INSERT INTO employees (name) VALUES ('Alice'), ('Bob'); SELECT * FROM employees"

./scripts/basebackup.sh
sleep 1
RESTORE=`date '+%Y-%m-%d %H:%M:%S'`; echo $RESTORE

docker compose exec postgres psql -c "DELETE FROM employees WHERE id = 1; SELECT * FROM employees"

./scripts/restore.sh $RESTORE
sleep 3
docker compose exec postgres psql -c "SELECT * FROM employees"

############

# Sākam svaigi
sudo kubectl delete -f k8/deployment.yaml -f k8/cronjob.yaml -f k8/backup-scripts-configmap.yaml
./scripts/reset_all.sh

# Modificējam k8/cronjob.yaml, ieraklstot laiku, kad tiek taisīti pilnie backupi
# Produkcijā 0 0 * * *, testiem var uzlikt +~1 min no esošā laika
sudo kubectl apply -f k8/deployment.yaml -f k8/cronjob.yaml -f k8/backup-scripts-configmap.yaml
sleep 5

# Testa pēc insērtojam datus
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "CREATE TABLE employees (id serial PRIMARY KEY, name text); INSERT INTO employees (name) VALUES ('Alice'), ('Bob'); SELECT * FROM employees"

# Pagaidām, kad nostrādā crons, kas uztaisa backup (būs pods postgres-backup... ar statusu completed), pēc tam var:

# Fiksējam laiku, ko gribēsim patīt atpakaļ
RESTORE=`date '+%Y-%m-%d %H:%M:%S'`; echo $RESTORE

# Dzēšam datus, parādam kas paliek pāri
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "DELETE FROM employees WHERE id = 1; SELECT * FROM employees"

# Atjaunojam datubāzi līdz $RESTORE laikam
./k8/restore.sh "$RESTORE"

# Pārbaudām, vai dati ir atgriezušies
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "SELECT * FROM employees"

```

## Kubernetes — PITR restore

```bash
# Restore the database to a specific point in time.
# Timestamp must be in Europe/Riga local time.
./k8/restore.sh "2026-04-13 22:00:00"

# Monitor recovery progress (wait for "database system is ready to accept connections")
kubectl logs -f $(kubectl get pod -l app=postgres -o name)

# Verify data is back
kubectl exec -it $(kubectl get pod -l app=postgres -o name) -- psql -U postgres -c "SELECT * FROM employees;"
```

What `k8/restore.sh` does:
1. Flushes the active WAL segment so nothing is lost
2. Scales the `postgres` Deployment to 0 (stops the pod)
3. Runs a one-off pod that replaces the data dir with the latest base backup and writes `recovery_target_time` + `recovery.signal`
4. Scales the Deployment back to 1 — PostgreSQL replays WAL up to the target time and promotes to read/write

To trigger a manual backup before restoring:
```bash
kubectl create job --from=cronjob/postgres-backup manual-backup
# Wait for it to complete
kubectl get pods -w
```