#!/bin/sh
docker compose down
sudo rm -rf backup data