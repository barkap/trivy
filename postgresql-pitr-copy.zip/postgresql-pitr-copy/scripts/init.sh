#!/bin/sh
mkdir -p data backup/base backup/wal
chmod 0777 -R data backup