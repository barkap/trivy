#!/bin/bash
# Take a base backup of the running PostgreSQL instance.
#
# Each backup is stored in a dated subdirectory: ./backup/base/YYYY-MM-DD/
# Running this script again on the same day overwrites that day's backup.
#
# Typical schedule: run once daily at 00:00, then run cleanup_base.sh to
# prune backups older than the retention window.

set -e

DATE=$(TZ='Europe/Riga' date '+%Y-%m-%d')
BACKUP_DIR="/var/lib/postgresql/basebackup/$DATE"

echo "Taking base backup for $DATE..."

# Remove today's directory if it already exists so pg_basebackup can write cleanly
docker compose run --rm --no-deps \
  --entrypoint sh postgres -c "rm -rf '$BACKUP_DIR'"

# pg_basebackup connects via the local Unix socket
# -D  : destination directory inside the container
# -Fp : plain format (directory copy)
# -Xs : stream WAL during backup so the backup is self-consistent
# -P  : show progress
docker compose exec postgres pg_basebackup \
  -D "$BACKUP_DIR" \
  -Fp -Xs -P \
  -U postgres

echo ""
echo "Base backup complete: $BACKUP_DIR"
echo "Timestamp: $(TZ='Europe/Riga' date '+%Y-%m-%d %H:%M:%S') Europe/Riga"
