# Description
This is a project which is ment for creating Proof of Concept scripts for Percona for PostgreSQL v18.3.

# Requirements
Requirements are stated in @docs/architecture.md file

# Instructions
- Don't create unnecessary code, nice to have code- always go for simplest solution which works
- Modify README.md file with info on how this project runs, all commands which are run by admin sholuld be commented and stated in README.md, keep it very simple
- Ask questions to gather more information for better config/architecture decisions. Answers should be weritten in simple form in @docs/architecture.md and this file should be red when code is generated.