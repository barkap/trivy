#!/bin/bash
# Restore the PostgreSQL database to a specific point in time (PITR) in Kubernetes.
#
# Usage:
#   ./k8/restore.sh "YYYY-MM-DD HH:MM:SS"
#
# The timestamp must be in Europe/Riga local time.
# Get the current Riga time with: TZ='Europe/Riga' date '+%Y-%m-%d %H:%M:%S'
#
# Example:
#   ./k8/restore.sh "2026-04-13 22:00:00"
#
# What this script does:
#   1. Flushes the active WAL segment to the archive
#   2. Scales the postgres Deployment to 0 (stops the pod)
#   3. Runs a one-off pod that restores the data dir from the latest base backup
#      and writes recovery settings (target time + promote action)
#   4. Scales the Deployment back to 1 — PostgreSQL enters recovery mode,
#      replays archived WAL up to the target time, then promotes to read/write

set -e

TARGET_TIME="$1"

if [ -z "$TARGET_TIME" ]; then
  echo "Usage: $0 \"YYYY-MM-DD HH:MM:SS\""
  exit 1
fi

POSTGRES_POD=$(kubectl get pod -l app=postgres -o name | head -1)

if [ -z "$POSTGRES_POD" ]; then
  echo "ERROR: No running postgres pod found. Is the deployment up?"
  exit 1
fi

echo "==> Flushing current WAL segment to archive..."
# Force a WAL segment switch so the active segment is archived before we stop the pod.
kubectl exec "$POSTGRES_POD" -- psql -U postgres -c "SELECT pg_switch_wal();" -t
sleep 2   # Give archive_command time to copy the segment

echo "==> Scaling down postgres deployment..."
kubectl scale deployment postgres --replicas=0
kubectl wait --for=delete pod -l app=postgres --timeout=60s

echo "==> Cleaning up any previous restore job..."
kubectl delete pod postgres-restore-job --ignore-not-found 2>/dev/null || true

echo "==> Running restore job..."
# Create a one-off pod with the same PVC mounted at the same subPaths as the
# postgres deployment, so it can access both the data dir and the base backups.
kubectl apply -f - <<EOF
apiVersion: v1
kind: Pod
metadata:
  name: postgres-restore-job
spec:
  restartPolicy: Never
  securityContext:
    runAsUser: 999
    runAsGroup: 999
  containers:
    - name: restore
      image: perconalab/percona-distribution-postgresql:18.3
      env:
        - name: TARGET_TIME
          value: "$TARGET_TIME"
      command:
        - sh
        - -c
        - |
          set -e
          echo "==> Finding most recent base backup..."
          LATEST=\$(ls -1d /var/lib/postgresql/basebackup/*/ 2>/dev/null | sort | tail -1 | tr -d '\n')
          if [ -z "\$LATEST" ]; then
            echo "ERROR: No base backup found in /var/lib/postgresql/basebackup/"
            echo "Trigger a backup first: kubectl create job --from=cronjob/postgres-backup manual-backup"
            exit 1
          fi
          echo "Using base backup: \$LATEST"
          echo "==> Restoring data directory..."
          rm -rf /var/lib/postgresql/data
          cp -rp "\$LATEST" /var/lib/postgresql/data
          echo "==> Writing recovery settings (target: \$TARGET_TIME)..."
          echo "recovery_target_time = '\$TARGET_TIME'" >> /var/lib/postgresql/data/postgresql.auto.conf
          echo "recovery_target_action = 'promote'"    >> /var/lib/postgresql/data/postgresql.auto.conf
          touch /var/lib/postgresql/data/recovery.signal
          echo "Done. Recovery settings written."
      volumeMounts:
        - name: storage
          mountPath: /var/lib/postgresql
          subPath: data
        - name: storage
          mountPath: /var/lib/postgresql/basebackup
          subPath: backup/base
  volumes:
    - name: storage
      persistentVolumeClaim:
        claimName: postgresql-pitr-pvc
EOF

echo "==> Waiting for restore job to complete..."
if ! kubectl wait pod/postgres-restore-job --for=jsonpath='{.status.phase}'=Succeeded --timeout=300s 2>/dev/null; then
  echo "ERROR: Restore job failed. Logs:"
  kubectl logs postgres-restore-job
  kubectl delete pod postgres-restore-job --ignore-not-found
  exit 1
fi
kubectl logs postgres-restore-job
kubectl delete pod postgres-restore-job

echo "==> Starting postgres in recovery mode..."
kubectl scale deployment postgres --replicas=1

echo ""
echo "Recovery started. PostgreSQL will replay WAL up to: $TARGET_TIME"
echo "Monitor progress:  kubectl logs -f \$(kubectl get pod -l app=postgres -o name)"
echo "Connect and verify: kubectl exec -it \$(kubectl get pod -l app=postgres -o name) -- psql -U postgres"
