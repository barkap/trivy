# Architecture
- Use Percona for PostgreSQL version 18.3
- Use Docker and Docker Compose to services, use `docker compose` commands to interact with services (validate working code)
- Project at some point will use Transparent Data Encryption (TDE) of percona postgresql, take it into account when designing and configuring
- Create all th db config files necessary for db, which should be mounted inside container

## Decisions

- **PITR mechanism**: built-in PostgreSQL `archive_command` + `pg_basebackup` (no extra tools)
- **WAL archive storage**: local Docker volume (`pgdata`), archive dir lives at `/var/lib/postgresql/archive` alongside the data dir
- **Topology**: single primary container; PITR restore is done in-place by replacing the data dir from the base backup
- **Retention**: single `scripts/cleanup.sh` prunes both base backups and WAL together (default 7 days). Base and WAL retention are always equal — a base backup without matching WAL is useless for PITR.
- **Timezone**: `Europe/Riga` everywhere — server, logs, WAL, recovery target. All timestamps in scripts and `restore.sh` are Riga local time. DST applies (UTC+2 winter, UTC+3 summer).
- **TDE**: out of scope for this PoC — config stubs (`pg_tde`) are already in `config/postgresql.conf` as comments